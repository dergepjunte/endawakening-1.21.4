package ja.endawakening;

import net.fabricmc.api.ClientModInitializer;

public class EndAwakeningClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {

    }
}
